package app.plink.fixture.actions25;

import android.app.RemoteInput;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import org.json.JSONObject;

public final class ActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent intent) {
        synchronized (FixtureState.LOCK) {
            try {
                SharedPreferences p = FixtureState.authority(c);
                String token = p.getString("token", null);
                long generation = p.getLong("generation", -1);
                if (!FixtureState.active(p) || token == null || !token.equals(intent.getStringExtra("token"))
                        || generation != intent.getLongExtra("generation", -2)) return;
                int index = -1;
                for (int k = 0; k < FixtureState.ACTIONS.length; k++) {
                    if ((FixtureReceiver.PREFIX + FixtureState.ACTIONS[k]).equals(intent.getAction())) index = k;
                }
                if (index < 0 || !("plink-fixture://actions25/" + generation + "/" + index)
                        .equals(intent.getDataString())) return;
                JSONObject r = FixtureState.read(c);
                if (r.getLong("generation") != generation) return;
                String counter = new String[]{"replyCount", "readCount", "archiveCount"}[index];
                r.put(counter, Math.addExact(r.getInt(counter), 1));
                if (index == 0) {
                    Bundle values = RemoteInput.getResultsFromIntent(intent);
                    int keys = values == null ? 0 : values.size();
                    boolean oneKey = keys == 1 && values.containsKey(FixtureState.INPUT);
                    CharSequence text = values == null ? null : values.getCharSequence(FixtureState.INPUT);
                    r.put("replyKeyCount", keys).put("replyIntendedKeyOnly", oneKey);
                    r.put("replyExactMatch", oneKey && text != null && "Plink25".contentEquals(text));
                }
                FixtureState.save(c, r);
                // Do not cancel/update/repost: the other original actions retain their own claims.
            } catch (Exception error) {
                // No text, token, Intent, exception message or notification content is logged.
            }
        }
    }
}
