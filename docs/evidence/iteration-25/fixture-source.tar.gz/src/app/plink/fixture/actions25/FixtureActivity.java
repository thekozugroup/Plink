package app.plink.fixture.actions25;

/** Launcher visibility for application artwork lookup; never posts or starts a trial. */
public final class FixtureActivity extends android.app.Activity {
    @Override public void onCreate(android.os.Bundle state) {
        super.onCreate(state);
        finish();
    }
}
