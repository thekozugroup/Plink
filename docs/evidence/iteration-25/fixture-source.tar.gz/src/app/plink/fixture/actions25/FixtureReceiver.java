package app.plink.fixture.actions25;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;

public final class FixtureReceiver extends BroadcastReceiver {
    static final int ID = 2525;
    static final String CHANNEL = "plink_actions25";
    static final String PREFIX = "app.plink.fixture.actions25.";

    @Override public void onReceive(Context c, Intent intent) {
        synchronized (FixtureState.LOCK) {
            NotificationManager manager = c.getSystemService(NotificationManager.class);
            try {
                if ((PREFIX + "STOP").equals(intent.getAction())) {
                    FixtureState.stop(c);
                    manager.cancel(ID);
                    setResultData("stopped_receipts_preserved");
                    return;
                }
                if (!(PREFIX + "POST").equals(intent.getAction())) return;
                SharedPreferences p = FixtureState.authority(c);
                if (FixtureState.active(p)) {
                    setResultData("already_active_no_repost");
                    return;
                }
                if (!manager.areNotificationsEnabled()) {
                    setResultData("notification_permission_required");
                    return;
                }
                manager.cancel(ID);
                long generation = FixtureState.begin(c);
                manager.createNotificationChannel(new NotificationChannel(CHANNEL,
                        "Plink action check", NotificationManager.IMPORTANCE_DEFAULT));
                Notification.Builder n = new Notification.Builder(c, CHANNEL)
                        .setSmallIcon(android.R.drawable.ic_dialog_email)
                        .setContentTitle("Plink action check")
                        .setContentText("Local test only. Reply with Plink25, Mark as read, or Archive.")
                        .setSubText("Run " + generation)
                        .setCategory(Notification.CATEGORY_MESSAGE)
                        .setAutoCancel(false).setTimeoutAfter(FixtureState.LIFETIME_MS);
                String[] labels = {"Reply", "Mark as read", "Archive"};
                for (int index = 0; index < FixtureState.ACTIONS.length; index++) {
                    Intent receipt = new Intent(c, ActionReceiver.class)
                            .setAction(PREFIX + FixtureState.ACTIONS[index])
                            .setData(Uri.parse("plink-fixture://actions25/" + generation + "/" + index))
                            .putExtra("generation", generation).putExtra("token", p.getString("token", null));
                    int flags = PendingIntent.FLAG_CANCEL_CURRENT |
                            (index == 0 ? PendingIntent.FLAG_MUTABLE : PendingIntent.FLAG_IMMUTABLE);
                    PendingIntent pi = PendingIntent.getBroadcast(c, ID + index, receipt, flags);
                    Notification.Action.Builder action = new Notification.Action.Builder(null, labels[index], pi);
                    if (index == 0) action.addRemoteInput(new RemoteInput.Builder(FixtureState.INPUT)
                            .setLabel("Reply").setAllowFreeFormInput(true).build());
                    n.addAction(action.build());
                }
                manager.notify(ID, n.build());
                setResultData("posted_generation_" + generation);
            } catch (Exception error) {
                // Fail closed after a partial POST, without exposing exception messages or authority.
                try { FixtureState.stop(c); } catch (Exception ignored) { }
                manager.cancel(ID);
                setResultData("fixture_failed:" + error.getClass().getSimpleName());
            }
        }
    }
}
