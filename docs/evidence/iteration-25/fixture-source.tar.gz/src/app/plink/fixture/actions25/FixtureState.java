package app.plink.fixture.actions25;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.util.AtomicFile;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.json.JSONObject;

final class FixtureState {
    static final Object LOCK = new Object();
    static final long LIFETIME_MS = 600_000;
    static final String[] ACTIONS = {"REPLY", "READ", "ARCHIVE"};
    static final String INPUT = "reply";

    static SharedPreferences authority(Context c) {
        return c.getSharedPreferences("authority", Context.MODE_PRIVATE);
    }

    static long begin(Context c) throws Exception {
        SharedPreferences p = authority(c);
        long generation = Math.addExact(p.getLong("generation", 0), 1);
        JSONObject r = new JSONObject();
        r.put("generation", generation);
        r.put("replyCount", 0).put("readCount", 0).put("archiveCount", 0);
        r.put("replyExactMatch", false).put("replyKeyCount", 0).put("replyIntendedKeyOnly", false);
        save(c, r);
        if (!p.edit().clear().putLong("generation", generation)
                .putString("token", UUID.randomUUID().toString())
                .putLong("elapsed", SystemClock.elapsedRealtime())
                .putLong("wall", System.currentTimeMillis()).commit()) {
            throw new IllegalStateException();
        }
        return generation;
    }

    static boolean active(SharedPreferences p) {
        long elapsed = SystemClock.elapsedRealtime() - p.getLong("elapsed", Long.MAX_VALUE);
        long wall = System.currentTimeMillis() - p.getLong("wall", Long.MAX_VALUE);
        return p.getString("token", null) != null && elapsed >= 0 && elapsed < LIFETIME_MS
                && wall >= 0 && wall < LIFETIME_MS;
    }

    static void stop(Context c) {
        if (!authority(c).edit().remove("token").commit()) throw new IllegalStateException();
    }

    static AtomicFile receipt(Context c) {
        return new AtomicFile(new File(c.getFilesDir(), "result.json"));
    }

    static JSONObject read(Context c) throws Exception {
        return new JSONObject(new String(receipt(c).readFully(), StandardCharsets.UTF_8));
    }

    static void save(Context c, JSONObject value) throws Exception {
        AtomicFile file = receipt(c);
        FileOutputStream stream = file.startWrite();
        try {
            stream.write(value.toString().getBytes(StandardCharsets.UTF_8));
            file.finishWrite(stream);
        } catch (Exception error) {
            file.failWrite(stream);
            throw error;
        }
    }
}
