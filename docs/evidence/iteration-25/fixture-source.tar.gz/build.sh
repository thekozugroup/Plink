#!/bin/bash
set -euo pipefail
FIXTURE_ROOT="$(cd "$(dirname "$0")" && pwd)"
FIXTURE_SDK="${FIXTURE_SDK:-$HOME/Library/Android/sdk}"
FIXTURE_JDK="${FIXTURE_JDK:-/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home}"
FIXTURE_TOOLS="$FIXTURE_SDK/build-tools/36.0.0"
FIXTURE_PLATFORM="$FIXTURE_SDK/platforms/android-36/android.jar"
export JAVA_HOME="$FIXTURE_JDK"
export PATH="$FIXTURE_JDK/bin:$PATH"
mkdir -p "$FIXTURE_ROOT/build" "$FIXTURE_ROOT/out"
STAGE="$(mktemp -d "$FIXTURE_ROOT/build/compile.XXXXXX")"
mkdir "$STAGE/classes" "$STAGE/host" "$STAGE/dex"
SRC="$FIXTURE_ROOT/src/app/plink/fixture/actions25"
javac -source 8 -target 8 -bootclasspath "$FIXTURE_PLATFORM" -d "$STAGE/classes" "$SRC"/*.java
jar cf "$STAGE/classes.jar" -C "$STAGE/classes" .
"$FIXTURE_TOOLS/d8" --min-api 26 --lib "$FIXTURE_PLATFORM" --output "$STAGE/dex" "$STAGE/classes.jar"
"$FIXTURE_TOOLS/aapt2" compile --dir "$FIXTURE_ROOT/res" -o "$STAGE/resources.zip"
"$FIXTURE_TOOLS/aapt2" link "$STAGE/resources.zip" -I "$FIXTURE_PLATFORM" --manifest "$FIXTURE_ROOT/AndroidManifest.xml" -o "$STAGE/unsigned.apk"
(cd "$STAGE/dex" && zip -q "$STAGE/unsigned.apk" classes.dex)
"$FIXTURE_TOOLS/zipalign" -f 4 "$STAGE/unsigned.apk" "$STAGE/aligned.apk"
KEY="$FIXTURE_ROOT/build/fixture-debug.keystore"
if [[ ! -f "$KEY" ]]; then
  keytool -genkeypair -keystore "$KEY" -storepass android -keypass android -alias fixture -keyalg RSA -keysize 2048 -validity 3650 -dname "CN=Plink synthetic fixture"
fi
"$FIXTURE_TOOLS/apksigner" sign --ks "$KEY" --ks-key-alias fixture --ks-pass pass:android --key-pass pass:android --out "$FIXTURE_ROOT/out/plink-actions25-fixture.apk" "$STAGE/aligned.apk"
"$FIXTURE_TOOLS/apksigner" verify --verbose "$FIXTURE_ROOT/out/plink-actions25-fixture.apk"
"$FIXTURE_TOOLS/aapt2" dump permissions "$FIXTURE_ROOT/out/plink-actions25-fixture.apk"
echo "Built $FIXTURE_ROOT/out/plink-actions25-fixture.apk"
