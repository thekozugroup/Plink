# Isolated iteration25 action fixture

Source implements `fixture-amendment-01.json`. Package `app.plink.fixture.actions25` is test-only and separate from Plink. No Internet, storage, account or contact permission; only its own notification permission. The launcher exists for package/artwork visibility and immediately finishes without posting.

Parent owns review, build, installation, device targeting, user readiness, execution and cleanup. Sol has not built or installed this fixture. Luna must review before installation.

## Parent procedure

1. Confirm this package is absent and the intended physical target is selected. Build with `bash build.sh` from this directory. It uses the prior fixture's standalone javac/d8/aapt2/signing pattern; SDK/JDK paths can be supplied with `FIXTURE_SDK` and `FIXTURE_JDK`. Output: `out/plink-actions25-fixture.apk`. Review its signature, package and permissions before installing with the test-only installation flag. Grant only this fixture's notification permission if required.
2. Establish the reviewed production binaries' fresh authenticated session and user readiness. Send an explicit shell broadcast to `app.plink.fixture.actions25/.FixtureReceiver`, action `app.plink.fixture.actions25.POST`. Receiver is protected by `android.permission.DUMP`. No launch, install or permission grant posts anything.
3. Start the five-minute observation period at POST. The one notification has original actions in order: Reply, Mark as read, Archive. User acts from native Mac notification UI; Reply text is exactly `Plink25`. Each receipt changes only its corresponding counter. Keep screenshot/user-origin confirmation separate from receiver evidence.
4. Read only `files/result.json` through the package's debug `run-as` context. It contains generation, three counters, reply key count, intended-key-only and exact-match booleans. Never read/export `shared_prefs/authority.xml`: it holds the random run authority. Collect receipts between actions when useful. Do not invoke the action receiver or PendingIntents directly.
5. Send explicit control action `app.plink.fixture.actions25.STOP` to the same control receiver. It invalidates the token and cancels notification 2525, retaining receipts. Collect final receipts, then uninstall only this owned fixture and remove parent-owned helper/build files as appropriate. Preserve production Plink, pairing, permissions and power settings.

One card is sufficient at the Android source: receipts neither cancel nor update it. Native Mac UI may dismiss a card after an action. If remaining controls cannot be reached, record that limitation; only a named, approved bounded follow-up may use STOP then POST. Collect the earlier generation's receipt first. POST refuses an already-active run; a later POST starts a fresh generation and resets counters. There is no automatic repost or retry.

## Bounds and interpretation

Distinct request codes, action strings and generation-specific data URIs prevent PendingIntent aliasing. Reply uses one mutable explicit PendingIntent and one free-form `reply` RemoteInput; other actions use immutable explicit PendingIntents. All target the non-exported owned receiver. Every receipt must match current random token, generation, action and data identity. STOP removes authority. Monotonic and wall-clock windows both reject receipts outside ten minutes from POST; Android notification timeout also removes the card. No alarms, services or foreground worker are used.

All authority/receipt updates run under one process lock; receipt replacement uses AtomicFile. Counts intentionally retain duplicate deliveries instead of suppressing them: acceptance requires exactly one intended increment per deliberate action and zero other increments. Reply text is compared transiently and never saved or printed. No receipt proves Mac origin by itself. Exact `Plink25` only proves this ASCII payload; simulated Unicode evidence remains separate. No real provider/account/message action occurs.

STOP preserves result.json for collection. Source/build outputs contain no run token. Private authority and receipts disappear on uninstall. Source-only checks do not substitute for parent compilation, Luna review or live acceptance.
