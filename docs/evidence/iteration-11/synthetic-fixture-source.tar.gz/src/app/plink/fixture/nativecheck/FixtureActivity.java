package app.plink.fixture.nativecheck;

/** Gives this synthetic source app the same visibility contract as a user-facing app. */
public final class FixtureActivity extends android.app.Activity {
    @Override public void onCreate(android.os.Bundle state) {
        super.onCreate(state);
        android.widget.TextView label = new android.widget.TextView(this);
        label.setText("Plink notification artwork check");
        setContentView(label);
    }
}
