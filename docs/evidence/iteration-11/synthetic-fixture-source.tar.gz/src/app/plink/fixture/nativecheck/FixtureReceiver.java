package app.plink.fixture.nativecheck;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.UUID;
public final class FixtureReceiver extends BroadcastReceiver {
 static final int ID=7111;
 static final String CHANNEL="plink_icon_check";
 @Override public void onReceive(Context c, Intent i) {
  try {
   NotificationManager manager=c.getSystemService(NotificationManager.class);
   if ("STOP".equals(i.getAction())) {
    manager.cancel(ID); manager.deleteNotificationChannel(CHANNEL);
    for (String n:new String[]{"token","result.json","source.png","launcher.png"}) new File(c.getFilesDir(),n).delete();
    setResultData("cleaned"); return;
   }
   if (!"POST".equals(i.getAction())) return;
   write(c,"source.png",c.getPackageName()); write(c,"launcher.png","app.plink.android");
   String token=UUID.randomUUID().toString();
   Files.write(new File(c.getFilesDir(),"token").toPath(),token.getBytes(StandardCharsets.UTF_8));
   Files.write(new File(c.getFilesDir(),"result.json").toPath(),"{\"count\":0,\"matched\":0}".getBytes(StandardCharsets.UTF_8));
   manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Plink icon check",NotificationManager.IMPORTANCE_DEFAULT));
   Intent reply=new Intent(c,ReplyReceiver.class).setAction("REPLY").putExtra("token",token);
   PendingIntent pending=PendingIntent.getBroadcast(c,ID,reply,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_MUTABLE);
   Notification.Action action=new Notification.Action.Builder(null,"Reply",pending).addRemoteInput(new RemoteInput.Builder("reply").setLabel("Reply").build()).build();
   Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_email).setContentTitle("Plink icon check").setContentText("Phone notification icon check. Reply with testword.").setCategory(Notification.CATEGORY_MESSAGE).addAction(action).build();
   manager.notify(ID,n); setResultData("posted");
  } catch(Exception e) { setResultData("fixture_failed:"+e.getClass().getSimpleName()); }
 }
 private static void write(Context c,String name,String pkg)throws Exception {
  Drawable d=c.getPackageManager().getApplicationIcon(pkg);
  int size="source.png".equals(name)?96:256;
  Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);
  d.setBounds(0,0,size,size); d.draw(new Canvas(b));
  try(FileOutputStream out=new FileOutputStream(new File(c.getFilesDir(),name))){b.compress(Bitmap.CompressFormat.PNG,100,out);} finally {b.recycle();}
 }
}
