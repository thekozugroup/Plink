package app.plink.fixture.nativecheck;
import android.app.*;
import android.content.*;
import android.os.Bundle;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import org.json.JSONObject;
public final class ReplyReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  try {
   if(!"REPLY".equals(i.getAction()))return;
   String token=new String(Files.readAllBytes(new File(c.getFilesDir(),"token").toPath()),StandardCharsets.UTF_8);
   if(!token.equals(i.getStringExtra("token")))return;
   Bundle values=RemoteInput.getResultsFromIntent(i);
   CharSequence text=values==null?null:values.getCharSequence("reply");
   File file=new File(c.getFilesDir(),"result.json");
   JSONObject r=new JSONObject(new String(Files.readAllBytes(file.toPath()),StandardCharsets.UTF_8));
   r.put("count",r.getInt("count")+1); if(text!=null && "testword".contentEquals(text))r.put("matched",r.getInt("matched")+1);
   Files.write(file.toPath(),r.toString().getBytes(StandardCharsets.UTF_8));
   c.getSystemService(NotificationManager.class).cancel(FixtureReceiver.ID);
  }catch(Exception ignored){}
 }
}
