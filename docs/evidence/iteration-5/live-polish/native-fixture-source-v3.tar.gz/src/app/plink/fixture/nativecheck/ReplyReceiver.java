package app.plink.fixture.nativecheck;

import android.app.NotificationManager;
import android.app.RemoteInput;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import org.json.JSONObject;

public final class ReplyReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !FixtureActivity.REPLY.equals(intent.getAction()) || intent.getData() == null) return;
        try {
            if (!FixtureActivity.tokenFile(context).exists()) return;
            String activeToken = new String(Files.readAllBytes(FixtureActivity.tokenFile(context).toPath()), StandardCharsets.UTF_8);
            if (!activeToken.equals(intent.getData().getLastPathSegment())) return;
            JSONObject previous = new JSONObject(new String(FixtureActivity.resultFile(context).readFully(), StandardCharsets.UTF_8));
            ReplyTally tally = new ReplyTally();
            tally.count = previous.getLong("count");
            tally.matchedCount = previous.getLong("matchedCount");
            Bundle results = RemoteInput.getResultsFromIntent(intent);
            tally.record(results == null ? null : results.getCharSequence(FixtureActivity.KEY));
            FixtureActivity.writeResult(context, tally.json());
            Log.i(FixtureActivity.TAG, "REPLY_RESULT " + tally.json().trim());
            context.getSystemService(NotificationManager.class).cancel(FixtureActivity.ID);
        } catch (Exception failure) {
            // Never log the Intent, Bundle, reply, or exception message.
            Log.e(FixtureActivity.TAG, "REPLY_RECORD_FAILED");
        }
    }
}
