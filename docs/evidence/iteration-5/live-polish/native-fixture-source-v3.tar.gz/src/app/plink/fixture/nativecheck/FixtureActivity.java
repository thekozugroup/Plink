package app.plink.fixture.nativecheck;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.AtomicFile;
import android.util.Log;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.UUID;
import org.json.JSONObject;

public final class FixtureActivity extends Activity {
    static final String PACKAGE = "app.plink.fixture.nativecheck";
    static final String POST = PACKAGE + ".POST";
    static final String STOP = PACKAGE + ".STOP";
    static final String CLIP_COPY = PACKAGE + ".CLIP_COPY";
    static final String CLIP_READ = PACKAGE + ".CLIP_READ";
    static final String CLIP_CLEAN = PACKAGE + ".CLIP_CLEAN";
    static final String REPLY = PACKAGE + ".REPLY";
    static final String KEY = "fixture_reply";
    static final String CHANNEL = "synthetic_reply_check";
    static final String TAG = "PlinkNativeFixture";
    static final int ID = 7101;
    private boolean awaitingPermission;
    private boolean resumed;
    private boolean clipboardPerformed;
    private String clipboardAction;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable clipboardProbe = new Runnable() {
        @Override public void run() { runClipboardProbe(); }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        awaitingPermission = state != null && state.getBoolean("awaitingPermission");
        if (!awaitingPermission) handle(getIntent());
        clipboardPerformed = state != null && state.getBoolean("clipboardPerformed");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        state.putBoolean("awaitingPermission", awaitingPermission);
        state.putBoolean("clipboardPerformed", clipboardPerformed);
        super.onSaveInstanceState(state);
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        if (clipboardPerformed) finish();
        else scheduleClipboardProbe();
    }

    @Override protected void onPause() {
        resumed = false;
        handler.removeCallbacks(clipboardProbe);
        super.onPause();
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        handler.removeCallbacks(clipboardProbe);
        if (focused) scheduleClipboardProbe();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void scheduleClipboardProbe() {
        handler.removeCallbacks(clipboardProbe);
        if (resumed && hasWindowFocus() && !isFinishing()
            && clipboardAction != null && !clipboardPerformed)
            handler.postDelayed(clipboardProbe, 500);
    }

    private void runClipboardProbe() {
        if (!resumed || !hasWindowFocus() || isFinishing()
            || clipboardAction == null || clipboardPerformed) return;
        clipboardPerformed = true;
        try {
            ClipboardManager clipboard = getSystemService(ClipboardManager.class);
            if (CLIP_COPY.equals(clipboardAction)) {
                clipboard.setPrimaryClip(ClipData.newPlainText("Plink synthetic check", "Plink Pixel clipboard check"));
                Log.i(TAG, "CLIP_COPY_COMPLETED");
            } else if (CLIP_CLEAN.equals(clipboardAction)) {
                ClipData clip = clipboard.getPrimaryClip();
                ClipData.Item item = clip != null && clip.getItemCount() == 1 ? clip.getItemAt(0) : null;
                CharSequence text = item == null ? null : item.getText();
                // Check and clear in this foreground callback; never save or log the clipboard text.
                if (Build.VERSION.SDK_INT >= 28 && item != null && item.getUri() == null
                    && item.getIntent() == null && item.getHtmlText() == null && text != null
                    && ("Plink Pixel clipboard check".contentEquals(text)
                        || "Plink Mac clipboard check".contentEquals(text))) {
                    clipboard.clearPrimaryClip();
                    Log.i(TAG, "CLIP_CLEAN_CLEARED");
                } else Log.i(TAG, "CLIP_CLEAN_UNCHANGED");
            } else {
                AtomicFile file = clipboardResultFile(this);
                ReplyTally tally = new ReplyTally();
                if (file.getBaseFile().exists()) {
                    JSONObject previous = new JSONObject(new String(file.readFully(), StandardCharsets.UTF_8));
                    tally.count = previous.getLong("count");
                    tally.matchedCount = previous.getLong("matchedCount");
                }
                ClipData clip = clipboard.getPrimaryClip();
                // Compare plain text only. Never coerce a URI, persist, display, or log clipboard content.
                tally.record(clip != null && clip.getItemCount() == 1 ? clip.getItemAt(0).getText() : null,
                    "Plink Mac clipboard check");
                writeResult(file, tally.json());
                Log.i(TAG, "CLIP_READ_RECORDED");
            }
        } catch (Exception failure) {
            Log.e(TAG, "CLIPBOARD_OPERATION_FAILED");
        }
        if (CLIP_CLEAN.equals(clipboardAction)) { finish(); return; }
        handler.postDelayed(new Runnable() {
            @Override public void run() { finish(); }
        }, CLIP_COPY.equals(clipboardAction) ? 2000 : 1000);
    }

    private void handle(Intent intent) {
        handler.removeCallbacksAndMessages(null);
        clipboardAction = null;
        clipboardPerformed = false;
        awaitingPermission = false;
        String action = intent == null ? null : intent.getAction();
        try {
            if (STOP.equals(action)) {
                awaitingPermission = false;
                cleanup(this);
                clipboardResultFile(this).delete();
                for (String suffix : new String[] {"", ".bak", ".new"}) {
                    if (getFileStreamPath("clipboard-result.json" + suffix).exists()) throw new IllegalStateException();
                }
                Log.i(TAG, "CLEANUP_REQUESTED; owned files removed and notification cancelled");
                finishAndRemoveTask();
            } else if (CLIP_COPY.equals(action) || CLIP_READ.equals(action) || CLIP_CLEAN.equals(action)) {
                clipboardAction = action;
                TextView text = new TextView(this);
                text.setPadding(32, 32, 32, 32);
                text.setText(CLIP_COPY.equals(action)
                    ? "Synthetic clipboard copy check. Keep this activity visible briefly."
                    : CLIP_CLEAN.equals(action)
                        ? "Synthetic clipboard cleanup. Only exact fixture text can be cleared."
                        : "Synthetic clipboard read check. Only equality and counts are recorded.");
                setContentView(text);
                scheduleClipboardProbe();
            } else if (POST.equals(action)) {
                if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    awaitingPermission = true;
                    requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 1);
                } else post();
            } else {
                TextView text = new TextView(this);
                text.setPadding(32, 32, 32, 32);
                text.setText("Synthetic local fixture only.\n\nLaunch POST explicitly to show ‘Plink reply check’.\nReply with exactly: testword\n\nLaunch STOP to cancel and erase fixture data.\nNo external recipient or network permission.");
                setContentView(text);
            }
        } catch (Exception failure) {
            Log.e(TAG, "FIXTURE_OPERATION_FAILED");
            TextView text = new TextView(this);
            text.setText("Fixture operation failed. Check notification permission, then run STOP before retrying.");
            setContentView(text);
        }
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(request, permissions, grants);
        if (request != 1 || !awaitingPermission) return;
        awaitingPermission = false;
        if (grants.length == 1 && grants[0] == PackageManager.PERMISSION_GRANTED) handle(new Intent(POST));
        else { Log.i(TAG, "NOTIFICATION_PERMISSION_DENIED"); finish(); }
    }

    private void post() throws Exception {
        cleanup(this);
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL, "Synthetic reply check", NotificationManager.IMPORTANCE_HIGH));
        if (!manager.areNotificationsEnabled() || manager.getNotificationChannel(CHANNEL).getImportance() == NotificationManager.IMPORTANCE_NONE)
            throw new IllegalStateException();
        String token = UUID.randomUUID().toString();
        Files.write(tokenFile(this).toPath(), token.getBytes(StandardCharsets.UTF_8));
        writeResult(this, new ReplyTally().json());
        RemoteInput remote = new RemoteInput.Builder(KEY).setLabel("Reply with testword")
            .setAllowFreeFormInput(true).build();
        Notification.Action.Builder action = new Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_send), "Reply", replyIntent(this, token, PendingIntent.FLAG_CANCEL_CURRENT))
            .addRemoteInput(remote).setAllowGeneratedReplies(false);
        if (Build.VERSION.SDK_INT >= 28) action.setSemanticAction(Notification.Action.SEMANTIC_ACTION_REPLY);
        if (Build.VERSION.SDK_INT >= 31) action.setAuthenticationRequired(false);
        Notification notification = new Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("Plink reply check").setContentText("Reply with testword")
            .setCategory(Notification.CATEGORY_MESSAGE).setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(action.build()).setAutoCancel(false).build();
        manager.notify(ID, notification);
        Log.i(TAG, "POSTED_SYNTHETIC_CHECK; baseline count=0");
        finish();
    }

    static File tokenFile(Context context) { return context.getFileStreamPath("active-token"); }
    static AtomicFile resultFile(Context context) { return new AtomicFile(context.getFileStreamPath("result.json")); }
    static AtomicFile clipboardResultFile(Context context) { return new AtomicFile(context.getFileStreamPath("clipboard-result.json")); }

    static PendingIntent replyIntent(Context context, String token, int flags) {
        Intent intent = new Intent(context, ReplyReceiver.class).setAction(REPLY)
            .setData(Uri.parse("plink-fixture://reply/" + token));
        if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
        return PendingIntent.getBroadcast(context, 0, intent, flags);
    }

    static void writeResult(Context context, String json) throws Exception {
        writeResult(resultFile(context), json);
    }

    private static void writeResult(AtomicFile file, String json) throws Exception {
        FileOutputStream stream = file.startWrite();
        try {
            stream.write(json.getBytes(StandardCharsets.UTF_8));
            file.finishWrite(stream);
        } catch (Exception failure) { file.failWrite(stream); throw failure; }
    }

    static void cleanup(Context context) throws Exception {
        File tokenFile = tokenFile(context);
        if (tokenFile.exists()) {
            String token = new String(Files.readAllBytes(tokenFile.toPath()), StandardCharsets.UTF_8);
            PendingIntent pending = replyIntent(context, token, PendingIntent.FLAG_NO_CREATE);
            if (pending != null) pending.cancel();
            Files.delete(tokenFile.toPath());
        }
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.cancel(ID);
        manager.deleteNotificationChannel(CHANNEL);
        resultFile(context).delete();
        if (tokenFile.exists() || context.getFileStreamPath("result.json").exists()) throw new IllegalStateException();
    }
}
