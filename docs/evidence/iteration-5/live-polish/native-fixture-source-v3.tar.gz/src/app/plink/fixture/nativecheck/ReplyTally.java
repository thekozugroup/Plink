package app.plink.fixture.nativecheck;

/** Stores only synthetic equality results, never received text. */
final class ReplyTally {
    long count;
    long matchedCount;
    boolean lastMatched;

    void record(CharSequence reply) {
        record(reply, "testword");
    }

    void record(CharSequence reply, String expected) {
        count++;
        lastMatched = reply != null && expected.contentEquals(reply);
        if (lastMatched) matchedCount++;
    }

    String json() {
        return "{\"count\":" + count + ",\"matchedCount\":" + matchedCount
            + ",\"lastMatched\":" + lastMatched + "}\n";
    }

    public static void main(String[] args) {
        ReplyTally tally = new ReplyTally();
        tally.record("testword");
        if (tally.count != 1 || tally.matchedCount != 1 || !tally.lastMatched) throw new AssertionError();
        tally.record("testword");
        tally.record("do-not-retain-this-input");
        tally.record(null);
        if (tally.count != 4 || tally.matchedCount != 2 || tally.lastMatched
            || tally.json().contains("do-not-retain")) throw new AssertionError();
        System.out.println("PASS: exact match, duplicate count, mismatch/null, no text retention");
        ReplyTally clipboard = new ReplyTally();
        clipboard.record("Plink Mac clipboard check", "Plink Mac clipboard check");
        if (clipboard.count != 1 || clipboard.matchedCount != 1 || !clipboard.lastMatched) throw new AssertionError();
        clipboard.record("Plink Mac clipboard check ", "Plink Mac clipboard check");
        clipboard.record("Plink Pixel clipboard check", "Plink Mac clipboard check");
        clipboard.record(null, "Plink Mac clipboard check");
        if (clipboard.count != 4 || clipboard.matchedCount != 1 || clipboard.lastMatched
            || clipboard.json().contains("clipboard check")) throw new AssertionError();
        System.out.println("PASS: clipboard exact equality, direction/whitespace/null rejection, counts only");
    }
}
